/*

1. the output come is 15
cause the function (x *= y+1 ; ) is the same as x*(y+1) 
as we all know that x=5, and y=2 and y+1 is 3  then which mean is 
5 x 3 = 15 
that's all 
*/

//2 . the code is below 


#include <stdio.h>

int main ()
{
	int c ; 
	scanf ("%d", &c);
	int f ; 
	f = (c *9/5)+32 ;
	printf ("%d", f);
	return 0 ;
}