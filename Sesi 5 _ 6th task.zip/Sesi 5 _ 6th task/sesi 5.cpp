/*
Kasus:
  Seorang pengguna ingin mengetahui kategori berat badannya berdasarkan Body Mass Index (BMI).
  Spesifikasi: Input Berat badan (kilogram, dapat berupa pecahan)
  Tinggi badan (meter, dapat berupa pecahan)
  Proses Hitung BMI: BMI = berat / (tinggi * tinggi)
  Tentukan kategori berat badan:
  BMI < 18.5 ? Kurus18.5 = BMI = 24.9 ? NormalBMI
  BMI = 25 ? Berat badan berlebih
  Output Nilai BMI dengan dua angka di belakang koma
  Kategori berat badan sesuai hasil perhitungan
  
  
  Contoh Ouput 1 :
 	Silahkan Masukkan Berat Badan Anda (kg): 68
	Silahkan Masukkan Tinggi Badan Anda (meter): 1.70
	BMI Anda adalah : 23.53
	Kategori : Normal
  Contoh Ouput 2 :
  	Silahkan Masukkan Berat Badan Anda (kg): 50
	Silahkan Masukkan Tinggi Badan Anda (meter): 1.65
	BMI Anda adalah : 18.37
	Kategori : Kurus
  Contoh Ouput 3 :	
  	Silahkan Masukkan Berat Badan Anda (kg): 85
	Silahkan Masukkan Tinggi Badan Anda (meter): 1.70
	BMI Anda adalah : 29.41
	Anda dikategorikan Kelebihan Berat Badan.

*/


#include <stdio.h>

int main ()
{
	float BD, TB ;
	printf ("Silahkan Masukan Berat Badan Anda: ");
	scanf ("%f", &BD);
	printf ("Silahkan Masukan Berat Badan Anda: ");
	scanf ("%f", &TB);
	float BMI ;
	
	BMI  = BD / (TB*TB) ;
	printf("BMI Anda adalah : %.2f\n", BMI);
	
	if (BMI < 18.5f)
	{
		printf("Anda dikagetorikan Kurus.\n");
	}
	else if (BMI < 25.0f)
	{
		printf ("Anda diketegorikan Normal.\n");
	}
	else 
	{
		printf ("Anda diketegorikan Gendut.\n");
	}
	
	return 0 ;
}