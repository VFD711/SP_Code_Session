#include <stdio.h>

int main ()
{
	char nama [10];
	scanf("%[^\n]", nama); 
	int umur ;
	scanf ("%d", &umur);
	
	printf ("Siapa kamu ? %s\n", nama); 
	printf ("Umur kamu berapa ? %d\n", umur); 
	
	return 0 ;
}