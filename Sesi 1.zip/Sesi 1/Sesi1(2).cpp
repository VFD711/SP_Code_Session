#include <stdio.h>

int main ()
{
	int n ; 
	float N ;
	
	scanf ("%d", &n); 
	scanf ("%f", &N); 
	
	printf ("Integer : %d \n", n);
	printf ("Decimal : %.2f \n", N);
	return 0 ;
}